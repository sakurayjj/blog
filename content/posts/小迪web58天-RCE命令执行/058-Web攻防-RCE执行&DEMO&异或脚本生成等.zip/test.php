<?php

//RCE代码执行 ->命令执行
//http://192.168.1.4:82/rce/test.php?c=system('ver');
//$code=$_GET['c'];
//eval($code);
//http://192.168.1.4:82/rce/test.php?c=phpinfo();
//$code=phpinfo();
//将phpinfo();当做当前语言代码去执行 代码执行漏洞
//产生条件：可控变量code 触发函数eval

//$code=system('ver');


//$code=$_GET['c'];
//assert($code);

//eval()、assert()、preg_replace()、create_function()、
//array_map()、call_user_func()、call_user_func_array()、array_filter()、uasort()

//RCE命令执行
//$cmd=$_GET['c'];
//system($cmd);
//echo "<hr>";
//
//echo exec($cmd);
//echo "<hr>";
//
//echo shell_exec($cmd);
//echo "<hr>";
//
//passthru($cmd);
//echo "<hr>";

echo ("%08%02%08%08%05%0d"^"%7b%7b%7b%7c%60%60");

//http://192.168.1.4:82/rce/test.php?c=ver
//$cmd=ver
//将ver当做当前系统命令去执行 命令执行漏洞
//产生条件：可控变量cmd 触发函数system
//用到php去运行代码
//system()、exec()、shell_exec()、pcntl_exec()、popen()、proc_popen()、passthru()、等