<?php
error_reporting(0);
highlight_file(__FILE__);
$code=$_GET['code'];
shell_exec($code);